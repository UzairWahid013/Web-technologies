console.log('this is me');
function checkPassword() {
  var password = document.getElementById('password').value;
  var retype_password = document.getElementById('retype_password').value;
  console.log(password, retype_password);
  var message = document.getElementById('message');
  if (password.length != 0) {
    if (password == retype_password) {
    }
    else {
      message.textContent = ("Password  doesnot match");
      message.style.backgroundColor = "#FF0000";
    }
  }
}